package com.example.lafyuu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
